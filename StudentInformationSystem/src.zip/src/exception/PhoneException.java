package exception;

public class PhoneException extends RuntimeException{
	public PhoneException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
