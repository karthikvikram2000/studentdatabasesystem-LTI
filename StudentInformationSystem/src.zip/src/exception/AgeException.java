package exception;

public class AgeException extends Throwable {
	public AgeException(String message) {
		super(message);
	}
}
